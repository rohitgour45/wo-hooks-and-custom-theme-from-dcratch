# WordPress101
Public Repository for the series of Tutorials "Wordpress 101 for beginner developers"

[Tutorials](https://www.youtube.com/playlist?list=PLriKzYyLb28nUFbe0Y9d-19uVkOnhYxFE)
