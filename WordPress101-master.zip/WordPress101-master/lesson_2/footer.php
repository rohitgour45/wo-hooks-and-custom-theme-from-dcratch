	
	<footer>
		<p>This is my footer</p>
	</footer>
	
	<?php wp_footer(); ?>
	
	</body>
</html>